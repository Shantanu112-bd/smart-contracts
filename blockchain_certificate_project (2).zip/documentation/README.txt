# Blockchain-Based Certificate Issuance and Verification System

## 🔍 Introduction
This project is a blockchain-based system designed to issue and verify academic certificates securely and transparently. It ensures tamper-proof certification using smart contracts on the Ethereum/Polygon network.

## 💡 Problem Statement
Traditional certificate verification is slow, prone to errors, and can be easily forged. Our solution makes the process secure and transparent using blockchain.

## ⚙️ Technologies Used
- **Solidity** – Smart contract development
- **Ethereum/Polygon** – Blockchain network
- **React.js** – Frontend development
- **Ethers.js** – Interaction with blockchain
- **IPFS** – (optional) Decentralized storage
- **Node.js + MongoDB** – (optional) Backend support

## 🧩 Features
- Admin can issue a certificate by entering student details and certificate hash.
- Verifiers can verify authenticity using student ID or uploaded file hash.
- All records are stored immutably on the blockchain.

## 📁 Project Structure
- `/contracts`: Solidity smart contract for storing certificates
- `/frontend`: React.js frontend to interact with the blockchain
- `/documentation`: Report and documentation files

## 🚀 How to Run
1. Deploy the smart contract using Remix or Hardhat
2. Run frontend:
   ```bash
   cd frontend
   npm install
   npm start
   ```
3. Connect to Metamask and start issuing or verifying certificates

## 📌 Future Enhancements
- File upload and automatic hashing
- Integration with IPFS
- Role-based access control for university departments

## 📝 Author
Student Project for Blockchain Course – For S.R.T.M. University, Nanded
