import React from 'react';
import { ethers } from 'ethers';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Blockchain Certificate Verification</h1>
      <p>Use this app to issue or verify certificates.</p>
    </div>
  );
}

export default App;
